from __future__ import annotations

from bs4 import BeautifulSoup
from web_qa_mcp_agent.models import Finding


def audit_seo(html: str) -> list[Finding]:
    soup = BeautifulSoup(html, "html.parser")
    findings: list[Finding] = []
    title = soup.find("title")
    description = soup.find("meta", attrs={"name": "description"})
    h1s = soup.find_all("h1")

    if not title or not title.text.strip():
        findings.append(Finding(severity="medium", category="seo", title="Missing title",
            description="The page has no title tag.", evidence={}, recommendation="Add a concise, unique title tag."))
    elif len(title.text.strip()) > 65:
        findings.append(Finding(severity="low", category="seo", title="Long title",
            description="The page title may be too long for search snippets.", evidence={"length": len(title.text.strip())},
            recommendation="Keep title around 50-60 characters when possible."))

    if not description or not description.get("content"):
        findings.append(Finding(severity="medium", category="seo", title="Missing meta description",
            description="The page has no meta description.", evidence={}, recommendation="Add a clear meta description."))

    if len(h1s) == 0:
        findings.append(Finding(severity="medium", category="seo", title="Missing H1",
            description="The page has no H1 heading.", evidence={}, recommendation="Add one descriptive H1."))
    elif len(h1s) > 1:
        findings.append(Finding(severity="low", category="seo", title="Multiple H1 headings",
            description="The page contains more than one H1.", evidence={"count": len(h1s)}, recommendation="Use a single primary H1."))
    return findings
