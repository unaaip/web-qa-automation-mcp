from __future__ import annotations

from urllib.parse import urljoin, urlparse
import httpx
from bs4 import BeautifulSoup
from web_qa_mcp_agent.config import settings
from web_qa_mcp_agent.models import Finding


def extract_links(base_url: str, html: str, same_domain_only: bool = True) -> list[str]:
    soup = BeautifulSoup(html, "html.parser")
    base_host = urlparse(base_url).netloc
    links: list[str] = []
    for a in soup.find_all("a", href=True):
        href = a["href"].strip()
        if href.startswith(("mailto:", "tel:", "javascript:", "#")):
            continue
        absolute = urljoin(base_url, href)
        if same_domain_only and urlparse(absolute).netloc != base_host:
            continue
        if absolute not in links:
            links.append(absolute)
    return links


async def audit_links(base_url: str, html: str, limit: int | None = None) -> list[Finding]:
    max_links = limit or settings.max_links_to_check
    links = extract_links(base_url, html)[:max_links]
    broken: list[dict] = []
    async with httpx.AsyncClient(follow_redirects=True, timeout=8) as client:
        for link in links:
            try:
                response = await client.head(link)
                if response.status_code >= 400 or response.status_code == 405:
                    response = await client.get(link)
                if response.status_code >= 400:
                    broken.append({"url": link, "status": response.status_code})
            except Exception as exc:  # noqa: BLE001
                broken.append({"url": link, "error": str(exc)})
    if not broken:
        return []
    return [Finding(severity="medium", category="links", title="Broken or unreachable links",
        description="Some internal links failed during validation.", evidence={"checked": len(links), "broken": broken[:20]},
        recommendation="Fix, redirect, or remove broken internal links.")]
