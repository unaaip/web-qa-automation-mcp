from __future__ import annotations

from urllib.parse import urlparse
from bs4 import BeautifulSoup
from web_qa_mcp_agent.models import Finding


def audit_security(url: str, html: str) -> list[Finding]:
    soup = BeautifulSoup(html, "html.parser")
    findings: list[Finding] = []
    parsed = urlparse(url)
    if parsed.scheme != "https" and parsed.hostname not in {"localhost", "127.0.0.1"}:
        findings.append(Finding(severity="high", category="security", title="Page is not served over HTTPS",
            description="The audited URL does not use HTTPS.", evidence={"scheme": parsed.scheme},
            recommendation="Serve production websites over HTTPS only."))

    mixed = []
    if parsed.scheme == "https":
        for tag, attr in [("script", "src"), ("img", "src"), ("link", "href")]:
            for node in soup.find_all(tag):
                value = node.get(attr, "")
                if value.startswith("http://"):
                    mixed.append(value)
    if mixed:
        findings.append(Finding(severity="medium", category="security", title="Mixed content references",
            description="HTTPS page references insecure HTTP assets.", evidence={"examples": mixed[:10]},
            recommendation="Load all assets over HTTPS."))

    password_fields = soup.find_all("input", attrs={"type": "password"})
    if password_fields and parsed.scheme != "https" and parsed.hostname not in {"localhost", "127.0.0.1"}:
        findings.append(Finding(severity="critical", category="security", title="Password form on non-HTTPS page",
            description="Credentials may be exposed in transit.", evidence={"password_fields": len(password_fields)},
            recommendation="Only collect credentials on HTTPS pages."))
    return findings
