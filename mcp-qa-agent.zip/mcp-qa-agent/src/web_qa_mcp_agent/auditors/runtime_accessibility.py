from __future__ import annotations

from typing import Any

from web_qa_mcp_agent.browser.controller import browser_page


async def audit_runtime_accessibility(url: str) -> dict[str, Any]:
    async with browser_page() as page:
        response = await page.goto(url, wait_until="domcontentloaded")
        metrics = await page.evaluate(
            """
            () => {
              const imagesWithoutAlt = [...document.querySelectorAll('img')]
                .filter(img => !img.hasAttribute('alt')).length;
              const buttonsWithoutText = [...document.querySelectorAll('button')]
                .filter(b => !b.innerText.trim() && !b.getAttribute('aria-label')).length;
              const inputsWithoutLabel = [...document.querySelectorAll('input, textarea, select')]
                .filter(input => {
                  if (['hidden', 'submit', 'button'].includes(input.getAttribute('type'))) return false;
                  const id = input.getAttribute('id');
                  const hasLabel = id && document.querySelector(`label[for="${id}"]`);
                  return !hasLabel && !input.getAttribute('aria-label') && !input.getAttribute('aria-labelledby');
                }).length;
              const missingLang = !document.documentElement.getAttribute('lang');
              return { imagesWithoutAlt, buttonsWithoutText, inputsWithoutLabel, missingLang };
            }
            """
        )

    issues: list[str] = []
    if metrics["missingLang"]:
        issues.append("Missing html lang attribute")
    if metrics["imagesWithoutAlt"]:
        issues.append("Images without alt text detected")
    if metrics["buttonsWithoutText"]:
        issues.append("Buttons without visible text or aria-label detected")
    if metrics["inputsWithoutLabel"]:
        issues.append("Inputs without label, aria-label or aria-labelledby detected")

    return {
        "url": url,
        "status": response.status if response else None,
        "score": max(0, 100 - len(issues) * 20),
        "issues": issues,
        "metrics": metrics,
    }
