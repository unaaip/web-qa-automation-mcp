from __future__ import annotations

from bs4 import BeautifulSoup
from web_qa_mcp_agent.models import Finding


def audit_accessibility(html: str) -> list[Finding]:
    soup = BeautifulSoup(html, "html.parser")
    findings: list[Finding] = []

    if not soup.find("html", attrs={"lang": True}):
        findings.append(Finding(
            severity="medium", category="accessibility", title="Missing html lang attribute",
            description="The page does not declare a document language.",
            evidence={}, recommendation="Add lang to the html element, for example <html lang='en'>."
        ))

    missing_alt = [img.get("src", "") for img in soup.find_all("img") if not img.get("alt")]
    if missing_alt:
        findings.append(Finding(
            severity="medium", category="accessibility", title="Images without alt text",
            description="Some images do not provide alternative text for assistive technologies.",
            evidence={"count": len(missing_alt), "examples": missing_alt[:10]},
            recommendation="Add meaningful alt text, or empty alt text for decorative images."
        ))

    unlabeled_inputs = []
    labels_for = {label.get("for") for label in soup.find_all("label") if label.get("for")}
    for field in soup.find_all(["input", "textarea", "select"]):
        field_id = field.get("id")
        if field.get("type") in {"hidden", "submit", "button"}:
            continue
        if not field.get("aria-label") and not field.get("aria-labelledby") and field_id not in labels_for:
            unlabeled_inputs.append(field.get("name") or field_id or field.name)
    if unlabeled_inputs:
        findings.append(Finding(
            severity="high", category="accessibility", title="Form fields without labels",
            description="Interactive form controls need accessible names.",
            evidence={"count": len(unlabeled_inputs), "examples": unlabeled_inputs[:10]},
            recommendation="Associate every control with a label, aria-label, or aria-labelledby."
        ))

    return findings
