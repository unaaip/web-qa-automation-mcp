from __future__ import annotations

from typing import Any

from web_qa_mcp_agent.browser.controller import browser_page


async def audit_console_errors(url: str) -> dict[str, Any]:
    console_errors: list[str] = []
    console_warnings: list[str] = []
    page_errors: list[str] = []
    failed_requests: list[dict[str, Any]] = []

    async with browser_page() as page:
        page.on("console", lambda msg: console_errors.append(msg.text) if msg.type == "error" else None)
        page.on("console", lambda msg: console_warnings.append(msg.text) if msg.type == "warning" else None)
        page.on("pageerror", lambda exc: page_errors.append(str(exc)))
        page.on("requestfailed", lambda req: failed_requests.append({"url": req.url, "failure": str(req.failure)}))

        response = await page.goto(url, wait_until="domcontentloaded")
        await page.wait_for_timeout(1000)

    return {
        "url": url,
        "status": response.status if response else None,
        "console_error_count": len(console_errors),
        "console_warning_count": len(console_warnings),
        "page_error_count": len(page_errors),
        "failed_request_count": len(failed_requests),
        "console_errors": console_errors[:20],
        "console_warnings": console_warnings[:20],
        "page_errors": page_errors[:20],
        "failed_requests": failed_requests[:20],
    }
