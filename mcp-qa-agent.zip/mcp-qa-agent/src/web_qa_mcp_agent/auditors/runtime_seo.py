from __future__ import annotations

from typing import Any

from web_qa_mcp_agent.browser.controller import browser_page


async def audit_runtime_seo(url: str) -> dict[str, Any]:
    async with browser_page() as page:
        response = await page.goto(url, wait_until="domcontentloaded")
        data = await page.evaluate(
            """
            () => ({
              title: document.title || null,
              description: document.querySelector('meta[name="description"]')?.getAttribute('content') || null,
              h1Count: document.querySelectorAll('h1').length,
              canonical: document.querySelector('link[rel="canonical"]')?.getAttribute('href') || null,
              ogTitle: document.querySelector('meta[property="og:title"]')?.getAttribute('content') || null,
              robots: document.querySelector('meta[name="robots"]')?.getAttribute('content') || null,
              viewport: document.querySelector('meta[name="viewport"]')?.getAttribute('content') || null
            })
            """
        )

    issues: list[str] = []
    if not data["title"]:
        issues.append("Missing page title")
    elif len(data["title"]) > 65:
        issues.append("Page title is longer than 65 characters")
    if not data["description"]:
        issues.append("Missing meta description")
    if data["h1Count"] != 1:
        issues.append("Page should have exactly one H1")
    if not data["canonical"]:
        issues.append("Missing canonical URL")
    if not data["ogTitle"]:
        issues.append("Missing Open Graph title")
    if not data["viewport"]:
        issues.append("Missing viewport meta tag")

    return {
        "url": url,
        "status": response.status if response else None,
        "score": max(0, 100 - len(issues) * 12),
        "issues": issues,
        "metadata": data,
    }
