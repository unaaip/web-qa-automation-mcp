from __future__ import annotations

from playwright.async_api import Page
from web_qa_mcp_agent.models import Finding


async def collect_performance(page: Page) -> dict:
    return await page.evaluate("""
    () => {
      const nav = performance.getEntriesByType('navigation')[0];
      const resources = performance.getEntriesByType('resource');
      return {
        domContentLoadedMs: nav ? Math.round(nav.domContentLoadedEventEnd) : null,
        loadEventMs: nav ? Math.round(nav.loadEventEnd) : null,
        transferSizeBytes: resources.reduce((sum, r) => sum + (r.transferSize || 0), 0),
        resourceCount: resources.length
      }
    }
    """)


def audit_performance(metrics: dict) -> list[Finding]:
    findings: list[Finding] = []
    if metrics.get("loadEventMs") and metrics["loadEventMs"] > 5000:
        findings.append(Finding(severity="medium", category="performance", title="Slow page load",
            description="The browser load event took more than 5 seconds.", evidence=metrics,
            recommendation="Review heavy assets, caching, server latency, and critical rendering path."))
    if metrics.get("resourceCount", 0) > 120:
        findings.append(Finding(severity="low", category="performance", title="High number of resources",
            description="The page loads many resources.", evidence=metrics,
            recommendation="Bundle, defer, lazy-load, or remove unnecessary resources."))
    if metrics.get("transferSizeBytes", 0) > 3_000_000:
        findings.append(Finding(severity="medium", category="performance", title="Large transfer size",
            description="The page transfers more than 3 MB of resources.", evidence=metrics,
            recommendation="Compress images, minify assets, and enable caching/CDN."))
    return findings
