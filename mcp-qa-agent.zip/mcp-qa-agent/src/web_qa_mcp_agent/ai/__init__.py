"""LLM-powered analysis helpers for Web QA MCP Agent."""
