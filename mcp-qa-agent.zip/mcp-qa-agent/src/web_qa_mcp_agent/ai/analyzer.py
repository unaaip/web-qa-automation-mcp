from __future__ import annotations

import json
from typing import Any

import httpx

from web_qa_mcp_agent.config import settings


class LLMConfigurationError(RuntimeError):
    """Raised when no LLM provider is configured."""


def _compact_payload(payload: dict[str, Any], max_chars: int = 14000) -> str:
    text = json.dumps(payload, indent=2, ensure_ascii=False, default=str)
    if len(text) <= max_chars:
        return text
    return text[:max_chars] + "\n... [truncated for prompt size]"


QA_SYSTEM_PROMPT = (
    "You are a senior QA engineer and web performance specialist. "
    "Be concise, practical and specific. Prioritize issues by business impact."
)

def build_qa_prompt(audit_data: dict[str, Any]) -> str:
    return f"""Analyze the following website QA audit and produce a structured, business-oriented report.

Return Markdown with EXACTLY these sections:
## Executive Summary
## Score Breakdown
## Critical & High Priority Issues
## Medium & Low Priority Issues
## Recommended Actions (numbered, prioritized)
## Risk Level: [Low | Medium | High | Critical]
## Next QA Automation Steps

Rules:
- Be specific and actionable. No invented evidence.
- If score >= 90, confirm quality and suggest next steps.
- Include effort estimates (Quick Win / Medium / Large) per action.
- Mention accessibility, SEO, security and performance separately if findings exist.

Audit data:
```json
{_compact_payload(audit_data)}
```""".strip()


async def analyze_with_openai(audit_data: dict[str, Any]) -> dict[str, Any]:
    if not settings.openai_api_key:
        raise LLMConfigurationError("OPENAI_API_KEY is not set in .env")

    prompt = build_qa_prompt(audit_data)
    async with httpx.AsyncClient(timeout=settings.openai_timeout_seconds) as client:
        response = await client.post(
            "https://api.openai.com/v1/chat/completions",
            headers={
                "Authorization": f"Bearer {settings.openai_api_key}",
                "Content-Type": "application/json",
            },
            json={
                "model": settings.openai_model,
                "messages": [
                    {"role": "system", "content": QA_SYSTEM_PROMPT},
                    {"role": "user", "content": prompt},
                ],
                "temperature": settings.openai_temperature,
                "max_completion_tokens": settings.openai_max_tokens,
            },
        )

    if response.status_code >= 400:
        raise RuntimeError(f"OpenAI API error {response.status_code}: {response.text[:500]}")

    data = response.json()
    message = data["choices"][0]["message"]["content"]
    return {
        "provider": "openai",
        "model": settings.openai_model,
        "analysis_markdown": message,
        "usage": data.get("usage", {}),
    }


async def analyze_with_anthropic(audit_data: dict[str, Any]) -> dict[str, Any]:
    if not settings.anthropic_api_key:
        raise LLMConfigurationError("ANTHROPIC_API_KEY is not set in .env")

    prompt = build_qa_prompt(audit_data)
    async with httpx.AsyncClient(timeout=settings.anthropic_timeout_seconds) as client:
        response = await client.post(
            "https://api.anthropic.com/v1/messages",
            headers={
                "x-api-key": settings.anthropic_api_key,
                "anthropic-version": "2023-06-01",
                "Content-Type": "application/json",
            },
            json={
                "model": settings.anthropic_model,
                "max_tokens": settings.anthropic_max_tokens,
                "system": QA_SYSTEM_PROMPT,
                "messages": [{"role": "user", "content": prompt}],
            },
        )

    if response.status_code >= 400:
        raise RuntimeError(f"Anthropic API error {response.status_code}: {response.text[:500]}")

    data = response.json()
    message = data["content"][0]["text"]
    usage = data.get("usage", {})
    return {
        "provider": "anthropic",
        "model": settings.anthropic_model,
        "analysis_markdown": message,
        "usage": {
            "input_tokens": usage.get("input_tokens"),
            "output_tokens": usage.get("output_tokens"),
        },
    }


async def analyze_with_llm(audit_data: dict[str, Any]) -> dict[str, Any]:
    provider = settings.llm_provider
    if provider == "openai":
        return await analyze_with_openai(audit_data)
    if provider == "anthropic":
        return await analyze_with_anthropic(audit_data)
    raise LLMConfigurationError(
        f"Unsupported LLM_PROVIDER={provider!r}. Use 'openai' or 'anthropic'."
    )
