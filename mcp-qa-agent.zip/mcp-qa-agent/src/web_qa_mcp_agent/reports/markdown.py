from __future__ import annotations

import json
from pathlib import Path

from web_qa_mcp_agent.config import settings
from web_qa_mcp_agent.models import AuditResult, SEVERITY_EMOJI


def _severity_badge(severity: str) -> str:
    return f"{SEVERITY_EMOJI.get(severity, '•')} **{severity.upper()}**"


def to_markdown(result: AuditResult) -> str:
    by_sev = result.findings_by_severity
    lines = [
        "# 🔍 Web QA Audit Report",
        "",
        f"| Field | Value |",
        f"|-------|-------|",
        f"| **URL** | {result.url} |",
        f"| **Date** | {result.created_at} |",
        f"| **Score** | {result.score}/100 — *{result.score_label}* |",
        f"| **Total Findings** | {len(result.findings)} |",
        f"| **Duration** | {result.duration_ms} ms |",
        "",
        "## 📊 Findings Summary",
        "",
        "| Severity | Count |",
        "|----------|-------|",
    ]
    for sev in ("critical", "high", "medium", "low", "info"):
        count = len(by_sev[sev])
        if count:
            lines.append(f"| {SEVERITY_EMOJI[sev]} {sev.capitalize()} | {count} |")

    lines.append("")
    lines.append("## 📋 Findings Detail")

    for sev in ("critical", "high", "medium", "low", "info"):
        findings = by_sev[sev]
        if not findings:
            continue
        lines.append(f"\n### {SEVERITY_EMOJI[sev]} {sev.capitalize()} ({len(findings)})")
        for idx, f in enumerate(findings, start=1):
            lines.extend([
                f"\n**{idx}. {f.title}**",
                f"- Category: `{f.category}`",
                f"- {f.description}",
                f"- 💡 *{f.recommendation}*",
            ])
            if f.evidence:
                lines.append(f"- Evidence: `{json.dumps(f.evidence, ensure_ascii=False)}`")

    if not result.findings:
        lines.append("\n✅ No findings detected by the configured checks.")

    lines.extend([
        "",
        "## 🗂️ Metadata",
        "",
        f"```json\n{json.dumps(result.metadata, indent=2, ensure_ascii=False)}\n```",
    ])
    return "\n".join(lines)


def write_reports(result: AuditResult, basename: str = "web-qa-audit") -> dict:
    settings.report_dir.mkdir(parents=True, exist_ok=True)
    md_path = settings.report_dir / f"{basename}.md"
    json_path = settings.report_dir / f"{basename}.json"
    md_path.write_text(to_markdown(result), encoding="utf-8")
    json_path.write_text(result.model_dump_json(indent=2), encoding="utf-8")
    return {"markdown": str(md_path), "json": str(json_path)}
