from __future__ import annotations

import json
from datetime import UTC, datetime
from html import escape
from typing import Any

from web_qa_mcp_agent.config import settings
from web_qa_mcp_agent.models import AuditResult, SEVERITY_EMOJI


def _score_color(score: int) -> str:
    if score >= 90:
        return "#16a34a"
    if score >= 75:
        return "#d97706"
    if score >= 50:
        return "#ea580c"
    return "#dc2626"


def _finding_rows(findings: list[Any]) -> str:
    if not findings:
        return "<tr><td colspan='4' style='text-align:center;color:#6b7280'>✅ No findings</td></tr>"
    rows = []
    for f in findings:
        sev = f.severity if hasattr(f, "severity") else f.get("severity", "info")
        title = f.title if hasattr(f, "title") else f.get("title", "")
        category = f.category if hasattr(f, "category") else f.get("category", "")
        rec = f.recommendation if hasattr(f, "recommendation") else f.get("recommendation", "")
        emoji = SEVERITY_EMOJI.get(sev, "•")
        color_map = {"critical": "#fee2e2", "high": "#ffedd5", "medium": "#fef9c3", "low": "#f0fdf4", "info": "#f0f9ff"}
        bg = color_map.get(sev, "#f9fafb")
        rows.append(
            f'<tr style="background:{bg}">'
            f'<td>{emoji} {escape(sev.upper())}</td>'
            f'<td><code>{escape(category)}</code></td>'
            f'<td><strong>{escape(title)}</strong></td>'
            f'<td style="font-size:.85em;color:#374151">{escape(rec)}</td>'
            f'</tr>'
        )
    return "\n".join(rows)


def generate_html_report(
    url: str,
    seo: dict[str, Any],
    accessibility: dict[str, Any],
    console: dict[str, Any],
    audit_result: AuditResult | None = None,
) -> str:
    settings.report_dir.mkdir(parents=True, exist_ok=True)
    output = settings.report_dir / "audit-report.html"
    now = datetime.now(UTC).strftime("%Y-%m-%d %H:%M UTC")
    seo_score = seo.get("score", 0)
    acc_score = accessibility.get("score", 0)
    overall_score = audit_result.score if audit_result else round((seo_score + acc_score) / 2)
    findings_rows = _finding_rows(audit_result.findings if audit_result else [])
    duration = audit_result.duration_ms if audit_result else 0

    html = f"""<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>Web QA Audit — {escape(url)}</title>
  <style>
    *{{box-sizing:border-box;margin:0;padding:0}}
    body{{font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif;background:#f1f5f9;color:#1e293b}}
    header{{background:linear-gradient(135deg,#0f172a,#1e3a5f);color:#fff;padding:2rem 3rem}}
    header h1{{font-size:1.6rem;font-weight:700;margin-bottom:.25rem}}
    header .url{{opacity:.7;font-size:.9rem;word-break:break-all}}
    header .meta{{margin-top:.5rem;font-size:.8rem;opacity:.6}}
    main{{padding:2rem 3rem;display:grid;gap:1.5rem}}
    .grid-3{{display:grid;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:1rem}}
    .card{{background:#fff;border-radius:1rem;padding:1.5rem;box-shadow:0 4px 16px rgba(0,0,0,.06)}}
    .card h2{{font-size:.9rem;font-weight:600;text-transform:uppercase;letter-spacing:.05em;color:#64748b;margin-bottom:.75rem}}
    .big-score{{font-size:3rem;font-weight:800;line-height:1}}
    .badge{{display:inline-block;padding:.2rem .6rem;border-radius:.5rem;font-size:.75rem;font-weight:600;margin-top:.5rem}}
    .good{{color:#16a34a;background:#dcfce7}}.warn{{color:#d97706;background:#fef3c7}}.danger{{color:#dc2626;background:#fee2e2}}
    table{{width:100%;border-collapse:collapse;font-size:.875rem}}
    th{{background:#f8fafc;padding:.75rem 1rem;text-align:left;font-weight:600;color:#475569;border-bottom:2px solid #e2e8f0}}
    td{{padding:.65rem 1rem;border-bottom:1px solid #f1f5f9;vertical-align:top}}
    pre{{background:#f8fafc;border:1px solid #e2e8f0;border-radius:.5rem;padding:1rem;overflow-x:auto;font-size:.78rem;max-height:300px}}
    .tag{{display:inline-block;padding:.1rem .4rem;border-radius:.3rem;font-size:.7rem;font-weight:600;background:#e2e8f0;color:#475569}}
    footer{{text-align:center;padding:1.5rem;font-size:.75rem;color:#94a3b8}}
  </style>
</head>
<body>
  <header>
    <h1>🔍 Web QA Audit Report</h1>
    <div class="url">{escape(url)}</div>
    <div class="meta">Generated {escape(now)} · Duration {duration} ms</div>
  </header>
  <main>
    <section class="grid-3">
      <div class="card">
        <h2>Overall Score</h2>
        <div class="big-score" style="color:{_score_color(overall_score)}">{overall_score}</div>
        <span class="badge {'good' if overall_score>=90 else 'warn' if overall_score>=60 else 'danger'}">
          {'Excellent' if overall_score>=90 else 'Needs Work' if overall_score>=60 else 'Critical'}
        </span>
      </div>
      <div class="card">
        <h2>SEO Score</h2>
        <div class="big-score" style="color:{_score_color(seo_score)}">{seo_score}</div>
        <p style="margin-top:.5rem;font-size:.85rem;color:#64748b">{len(seo.get('issues', []))} issues found</p>
      </div>
      <div class="card">
        <h2>Accessibility</h2>
        <div class="big-score" style="color:{_score_color(acc_score)}">{acc_score}</div>
        <p style="margin-top:.5rem;font-size:.85rem;color:#64748b">{len(accessibility.get('issues', []))} issues found</p>
      </div>
      <div class="card">
        <h2>Console Errors</h2>
        <div class="big-score" style="color:{'#dc2626' if console.get('console_error_count',0)>0 else '#16a34a'}">{console.get('console_error_count', 0)}</div>
        <p style="margin-top:.5rem;font-size:.85rem;color:#64748b">{console.get('page_error_count', 0)} page errors</p>
      </div>
    </section>

    <div class="card">
      <h2>All Findings</h2>
      <table>
        <thead><tr><th>Severity</th><th>Category</th><th>Title</th><th>Recommendation</th></tr></thead>
        <tbody>{findings_rows}</tbody>
      </table>
    </div>

    <div class="card">
      <h2>Raw Audit Data</h2>
      <pre>{escape(json.dumps({'seo': seo, 'accessibility': accessibility, 'console': console}, indent=2))}</pre>
    </div>
  </main>
  <footer>Web QA MCP Agent · {escape(now)}</footer>
</body>
</html>"""

    output.write_text(html, encoding="utf-8")
    return str(output)
