from __future__ import annotations

from web_qa_mcp_agent.auditors.accessibility import audit_accessibility
from web_qa_mcp_agent.auditors.links import audit_links
from web_qa_mcp_agent.auditors.performance import audit_performance, collect_performance
from web_qa_mcp_agent.auditors.security import audit_security
from web_qa_mcp_agent.auditors.seo import audit_seo
from web_qa_mcp_agent.browser.controller import browser_page, open_page
from web_qa_mcp_agent.models import AuditResult


async def run_full_audit(url: str, check_links: bool = True) -> AuditResult:
    result = AuditResult(url=url)
    async with browser_page() as page:
        console_messages: list[dict] = []
        network_errors: list[dict] = []
        page.on("console", lambda msg: console_messages.append({"type": msg.type, "text": msg.text}))
        page.on("requestfailed", lambda req: network_errors.append({"url": req.url, "failure": req.failure}))
        response = await page.goto(url, wait_until="domcontentloaded")
        html = await page.content()
        final_url = page.url
        result.url = final_url
        metrics = await collect_performance(page)

    result.metadata = {
        "http_status": response.status if response else None,
        "performance": metrics,
        "console_messages": console_messages[:50],
        "network_errors": network_errors[:50],
    }
    result.findings.extend(audit_security(final_url, html))
    result.findings.extend(audit_accessibility(html))
    result.findings.extend(audit_seo(html))
    result.findings.extend(audit_performance(metrics))

    error_console = [m for m in console_messages if m.get("type") in {"error", "warning"}]
    if error_console:
        from web_qa_mcp_agent.models import Finding
        result.findings.append(Finding(severity="medium", category="runtime", title="Browser console issues",
            description="The page emitted console warnings or errors.", evidence={"messages": error_console[:20]},
            recommendation="Review frontend console output and fix client-side runtime issues."))
    if network_errors:
        from web_qa_mcp_agent.models import Finding
        result.findings.append(Finding(severity="medium", category="runtime", title="Network request failures",
            description="Some browser network requests failed.", evidence={"errors": network_errors[:20]},
            recommendation="Fix unavailable resources, failed APIs, or blocked assets."))
    if check_links:
        result.findings.extend(await audit_links(final_url, html))
    result.recalculate_score()
    return result


async def inspect_page(url: str) -> dict:
    page_data = await open_page(url)
    html = page_data.pop("html")
    page_data["html_size_bytes"] = len(html.encode("utf-8"))
    page_data["accessibility_findings"] = [f.model_dump() for f in audit_accessibility(html)]
    page_data["seo_findings"] = [f.model_dump() for f in audit_seo(html)]
    return page_data
