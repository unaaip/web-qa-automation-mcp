from __future__ import annotations

import base64
import json
from typing import Any

import httpx

from web_qa_mcp_agent.config import settings


class GitHubConfigurationError(RuntimeError):
    """Raised when GitHub credentials are not configured."""


def _require_github() -> tuple[str, str, str]:
    if not settings.github_token:
        raise GitHubConfigurationError("GITHUB_TOKEN is not set in .env")
    if not settings.github_owner or not settings.github_repo:
        raise GitHubConfigurationError("GITHUB_OWNER and GITHUB_REPO must be set in .env")
    return settings.github_token, settings.github_owner, settings.github_repo


def _headers(token: str) -> dict[str, str]:
    return {
        "Authorization": f"Bearer {token}",
        "Accept": "application/vnd.github+json",
        "X-GitHub-Api-Version": "2022-11-28",
        "Content-Type": "application/json",
    }


async def create_issue(
    title: str,
    body: str,
    labels: list[str] | None = None,
) -> dict[str, Any]:
    """Create a GitHub issue and return its data."""
    token, owner, repo = _require_github()
    payload: dict[str, Any] = {"title": title, "body": body}
    if labels:
        payload["labels"] = labels

    async with httpx.AsyncClient(timeout=30) as client:
        resp = await client.post(
            f"https://api.github.com/repos/{owner}/{repo}/issues",
            headers=_headers(token),
            json=payload,
        )

    if resp.status_code >= 400:
        raise RuntimeError(f"GitHub API error {resp.status_code}: {resp.text[:500]}")

    data = resp.json()
    return {
        "issue_number": data["number"],
        "url": data["html_url"],
        "title": data["title"],
        "state": data["state"],
    }


async def push_file(
    file_path: str,
    content: str,
    commit_message: str,
    branch: str | None = None,
) -> dict[str, Any]:
    """Create or update a file in the repository."""
    token, owner, repo = _require_github()
    branch = branch or settings.github_default_branch
    encoded = base64.b64encode(content.encode("utf-8")).decode()

    # Check if file exists to get its SHA (required for updates)
    sha: str | None = None
    async with httpx.AsyncClient(timeout=30) as client:
        check = await client.get(
            f"https://api.github.com/repos/{owner}/{repo}/contents/{file_path}",
            headers=_headers(token),
            params={"ref": branch},
        )
        if check.status_code == 200:
            sha = check.json().get("sha")

        payload: dict[str, Any] = {
            "message": commit_message,
            "content": encoded,
            "branch": branch,
        }
        if sha:
            payload["sha"] = sha

        resp = await client.put(
            f"https://api.github.com/repos/{owner}/{repo}/contents/{file_path}",
            headers=_headers(token),
            json=payload,
        )

    if resp.status_code >= 400:
        raise RuntimeError(f"GitHub API error {resp.status_code}: {resp.text[:500]}")

    data = resp.json()
    return {
        "file_path": file_path,
        "branch": branch,
        "commit_sha": data.get("commit", {}).get("sha"),
        "url": data.get("content", {}).get("html_url"),
        "action": "updated" if sha else "created",
    }


async def create_or_get_branch(branch_name: str, from_branch: str | None = None) -> dict[str, Any]:
    """Create a branch if it doesn't exist."""
    token, owner, repo = _require_github()
    base = from_branch or settings.github_default_branch

    async with httpx.AsyncClient(timeout=30) as client:
        # Get SHA of base branch
        ref_resp = await client.get(
            f"https://api.github.com/repos/{owner}/{repo}/git/ref/heads/{base}",
            headers=_headers(token),
        )
        if ref_resp.status_code >= 400:
            raise RuntimeError(f"Could not find base branch '{base}'")

        sha = ref_resp.json()["object"]["sha"]

        # Try to create branch
        create_resp = await client.post(
            f"https://api.github.com/repos/{owner}/{repo}/git/refs",
            headers=_headers(token),
            json={"ref": f"refs/heads/{branch_name}", "sha": sha},
        )

        if create_resp.status_code == 422:
            return {"branch": branch_name, "action": "already_exists", "sha": sha}
        if create_resp.status_code >= 400:
            raise RuntimeError(f"GitHub API error {create_resp.status_code}: {create_resp.text[:300]}")

        return {"branch": branch_name, "action": "created", "sha": sha}


async def create_pull_request(
    title: str,
    body: str,
    head_branch: str,
    base_branch: str | None = None,
    labels: list[str] | None = None,
) -> dict[str, Any]:
    """Open a Pull Request."""
    token, owner, repo = _require_github()
    base = base_branch or settings.github_default_branch

    async with httpx.AsyncClient(timeout=30) as client:
        resp = await client.post(
            f"https://api.github.com/repos/{owner}/{repo}/pulls",
            headers=_headers(token),
            json={"title": title, "body": body, "head": head_branch, "base": base},
        )

    if resp.status_code >= 400:
        raise RuntimeError(f"GitHub API error {resp.status_code}: {resp.text[:500]}")

    data = resp.json()
    pr: dict[str, Any] = {
        "pr_number": data["number"],
        "url": data["html_url"],
        "title": data["title"],
        "state": data["state"],
        "head": head_branch,
        "base": base,
    }

    # Add labels if provided
    if labels and data.get("number"):
        async with httpx.AsyncClient(timeout=30) as client:
            await client.post(
                f"https://api.github.com/repos/{owner}/{repo}/issues/{data['number']}/labels",
                headers=_headers(token),
                json={"labels": labels},
            )

    return pr


async def list_open_issues(label: str | None = None) -> list[dict[str, Any]]:
    """List open issues, optionally filtered by label."""
    token, owner, repo = _require_github()
    params: dict[str, str] = {"state": "open", "per_page": "50"}
    if label:
        params["labels"] = label

    async with httpx.AsyncClient(timeout=30) as client:
        resp = await client.get(
            f"https://api.github.com/repos/{owner}/{repo}/issues",
            headers=_headers(token),
            params=params,
        )

    if resp.status_code >= 400:
        raise RuntimeError(f"GitHub API error {resp.status_code}: {resp.text[:300]}")

    return [
        {
            "number": i["number"],
            "title": i["title"],
            "url": i["html_url"],
            "labels": [l["name"] for l in i.get("labels", [])],
            "created_at": i["created_at"],
        }
        for i in resp.json()
        if "pull_request" not in i  # exclude PRs
    ]


async def get_repo_info() -> dict[str, Any]:
    """Return basic repository info."""
    token, owner, repo = _require_github()
    async with httpx.AsyncClient(timeout=30) as client:
        resp = await client.get(
            f"https://api.github.com/repos/{owner}/{repo}",
            headers=_headers(token),
        )
    if resp.status_code >= 400:
        raise RuntimeError(f"GitHub API error {resp.status_code}: {resp.text[:300]}")
    data = resp.json()
    return {
        "full_name": data["full_name"],
        "description": data.get("description"),
        "default_branch": data["default_branch"],
        "open_issues_count": data["open_issues_count"],
        "html_url": data["html_url"],
        "topics": data.get("topics", []),
    }
