from __future__ import annotations

from datetime import datetime, timezone
from typing import Any, Literal
from pydantic import BaseModel, Field, HttpUrl

Severity = Literal["info", "low", "medium", "high", "critical"]

SEVERITY_PENALTIES: dict[str, int] = {
    "info": 0,
    "low": 3,
    "medium": 8,
    "high": 15,
    "critical": 25,
}

SEVERITY_EMOJI: dict[str, str] = {
    "info": "ℹ️",
    "low": "🟡",
    "medium": "🟠",
    "high": "🔴",
    "critical": "🚨",
}


class Finding(BaseModel):
    severity: Severity
    category: str
    title: str
    description: str
    evidence: dict[str, Any] = Field(default_factory=dict)
    recommendation: str

    @property
    def emoji(self) -> str:
        return SEVERITY_EMOJI.get(self.severity, "•")


class AuditResult(BaseModel):
    url: str
    created_at: str = Field(default_factory=lambda: datetime.now(timezone.utc).isoformat())
    score: int = 100
    findings: list[Finding] = Field(default_factory=list)
    metadata: dict[str, Any] = Field(default_factory=dict)
    duration_ms: int = 0

    def recalculate_score(self) -> int:
        self.score = max(0, 100 - sum(SEVERITY_PENALTIES[f.severity] for f in self.findings))
        return self.score

    @property
    def score_label(self) -> str:
        if self.score >= 90:
            return "Excellent"
        if self.score >= 75:
            return "Good"
        if self.score >= 50:
            return "Needs Attention"
        return "Critical"

    @property
    def findings_by_severity(self) -> dict[str, list[Finding]]:
        result: dict[str, list[Finding]] = {s: [] for s in SEVERITY_PENALTIES}
        for f in self.findings:
            result[f.severity].append(f)
        return result

    @property
    def critical_count(self) -> int:
        return sum(1 for f in self.findings if f.severity == "critical")

    @property
    def high_count(self) -> int:
        return sum(1 for f in self.findings if f.severity == "high")


class CrawlRequest(BaseModel):
    url: HttpUrl
    max_pages: int = Field(default=5, ge=1, le=25)


class GitHubIssueRequest(BaseModel):
    title: str
    body: str
    labels: list[str] = Field(default_factory=list)


class GitHubPushRequest(BaseModel):
    file_path: str
    content: str
    commit_message: str
    branch: str = "main"
