from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path

from dotenv import load_dotenv

load_dotenv()


@dataclass(frozen=True)
class Settings:
    # Server
    host: str = os.getenv("MCP_HOST", "0.0.0.0")
    port: int = int(os.getenv("MCP_PORT", "8000"))
    report_dir: Path = Path(os.getenv("REPORT_DIR", "./reports"))

    # Browser
    headless: bool = os.getenv("BROWSER_HEADLESS", "true").lower() == "true"
    default_timeout_ms: int = int(os.getenv("DEFAULT_TIMEOUT_MS", "15000"))
    max_links_to_check: int = int(os.getenv("MAX_LINKS_TO_CHECK", "40"))
    viewport_width: int = int(os.getenv("VIEWPORT_WIDTH", "1440"))
    viewport_height: int = int(os.getenv("VIEWPORT_HEIGHT", "1100"))

    # LLM – generic
    llm_provider: str = os.getenv("LLM_PROVIDER", "anthropic").lower()

    # OpenAI
    openai_api_key: str = os.getenv("OPENAI_API_KEY", "")
    openai_model: str = os.getenv("OPENAI_MODEL", "gpt-4o-mini")
    openai_temperature: float = float(os.getenv("OPENAI_TEMPERATURE", "0.2"))
    openai_max_tokens: int = int(os.getenv("OPENAI_MAX_TOKENS", "1500"))
    openai_timeout_seconds: float = float(os.getenv("OPENAI_TIMEOUT_SECONDS", "60"))

    # Anthropic
    anthropic_api_key: str = os.getenv("ANTHROPIC_API_KEY", "")
    anthropic_model: str = os.getenv("ANTHROPIC_MODEL", "claude-3-5-haiku-20241022")
    anthropic_max_tokens: int = int(os.getenv("ANTHROPIC_MAX_TOKENS", "1500"))
    anthropic_timeout_seconds: float = float(os.getenv("ANTHROPIC_TIMEOUT_SECONDS", "60"))

    # GitHub
    github_token: str = os.getenv("GITHUB_TOKEN", "")
    github_owner: str = os.getenv("GITHUB_OWNER", "")
    github_repo: str = os.getenv("GITHUB_REPO", "")
    github_default_branch: str = os.getenv("GITHUB_DEFAULT_BRANCH", "main")


settings = Settings()
settings.report_dir.mkdir(parents=True, exist_ok=True)
