from __future__ import annotations

import time
from typing import Any

from web_qa_mcp_agent.browser.controller import browser_page


async def run_web_journey(steps: list[dict[str, Any]]) -> dict[str, Any]:
    """Run a deterministic browser journey from MCP-friendly JSON steps."""
    results: list[dict[str, Any]] = []
    t0 = time.monotonic()

    async with browser_page() as page:
        for index, step in enumerate(steps, start=1):
            action = step.get("action")
            step_start = time.monotonic()
            try:
                if action == "goto":
                    await page.goto(str(step["url"]), wait_until="domcontentloaded")
                    results.append({"step": index, "action": action, "status": "passed", "url": page.url})

                elif action == "click":
                    await page.locator(str(step["selector"])).first.click()
                    results.append({"step": index, "action": action, "status": "passed"})

                elif action == "fill":
                    await page.locator(str(step["selector"])).first.fill(str(step.get("value", "")))
                    results.append({"step": index, "action": action, "status": "passed"})

                elif action == "press":
                    await page.locator(str(step["selector"])).first.press(str(step["key"]))
                    results.append({"step": index, "action": action, "status": "passed"})

                elif action == "wait_for_selector":
                    timeout = int(step.get("timeout_ms", 10000))
                    await page.locator(str(step["selector"])).first.wait_for(timeout=timeout)
                    results.append({"step": index, "action": action, "status": "passed"})

                elif action == "hover":
                    await page.locator(str(step["selector"])).first.hover()
                    results.append({"step": index, "action": action, "status": "passed"})

                elif action == "scroll_to":
                    await page.locator(str(step["selector"])).first.scroll_into_view_if_needed()
                    results.append({"step": index, "action": action, "status": "passed"})

                elif action == "select_option":
                    await page.locator(str(step["selector"])).first.select_option(str(step["value"]))
                    results.append({"step": index, "action": action, "status": "passed"})

                elif action == "wait_ms":
                    await page.wait_for_timeout(int(step.get("ms", 1000)))
                    results.append({"step": index, "action": action, "status": "passed"})

                elif action == "expect_url_contains":
                    expected = str(step["value"])
                    passed = expected in page.url
                    results.append({
                        "step": index, "action": action,
                        "status": "passed" if passed else "failed",
                        "expected": expected, "actual_url": page.url,
                    })

                elif action == "expect_text":
                    expected = str(step["text"])
                    content = await page.locator("body").inner_text(timeout=5000)
                    passed = expected.lower() in content.lower()
                    results.append({
                        "step": index, "action": action,
                        "status": "passed" if passed else "failed",
                        "expected": expected,
                    })

                elif action == "expect_element_visible":
                    visible = await page.locator(str(step["selector"])).first.is_visible()
                    results.append({
                        "step": index, "action": action,
                        "status": "passed" if visible else "failed",
                        "selector": step["selector"],
                    })

                elif action == "screenshot":
                    path = str(step.get("path", f"reports/journey-step-{index}.png"))
                    await page.screenshot(path=path, full_page=bool(step.get("full_page", True)))
                    results.append({"step": index, "action": action, "status": "passed", "path": path})

                elif action == "get_text":
                    text = await page.locator(str(step["selector"])).first.inner_text(timeout=5000)
                    results.append({"step": index, "action": action, "status": "passed", "text": text})

                elif action == "get_attribute":
                    attr = await page.locator(str(step["selector"])).first.get_attribute(str(step["attribute"]))
                    results.append({"step": index, "action": action, "status": "passed", "value": attr})

                else:
                    results.append({
                        "step": index, "action": action, "status": "failed",
                        "error": f"Unsupported action: {action}",
                    })

                results[-1]["duration_ms"] = int((time.monotonic() - step_start) * 1000)

            except Exception as exc:  # noqa: BLE001
                results.append({
                    "step": index, "action": action, "status": "failed",
                    "error": str(exc),
                    "duration_ms": int((time.monotonic() - step_start) * 1000),
                })

    passed = sum(1 for r in results if r["status"] == "passed")
    failed = sum(1 for r in results if r["status"] == "failed")
    return {
        "total_steps": len(steps),
        "passed": passed,
        "failed": failed,
        "success_rate": f"{round(passed / len(steps) * 100)}%" if steps else "0%",
        "total_duration_ms": int((time.monotonic() - t0) * 1000),
        "results": results,
    }
