from __future__ import annotations

from contextlib import asynccontextmanager
from pathlib import Path
from typing import AsyncIterator
from playwright.async_api import Browser, BrowserContext, Page, async_playwright
from web_qa_mcp_agent.config import settings


@asynccontextmanager
async def browser_page() -> AsyncIterator[Page]:
    async with async_playwright() as p:
        browser: Browser = await p.chromium.launch(
            headless=settings.headless,
            args=[
                "--no-sandbox",
                "--ignore-certificate-errors",
                "--ignore-ssl-errors",
                "--allow-running-insecure-content",
            ],
        )
        context: BrowserContext = await browser.new_context(
            ignore_https_errors=True,
            viewport={"width": 1440, "height": 1100},
            user_agent=(
                "Mozilla/5.0 (X11; Linux x86_64) "
                "AppleWebKit/537.36 (KHTML, like Gecko) "
                "Chrome/120.0.0.0 Safari/537.36"
            ),
        )
        page = await context.new_page()
        page.set_default_timeout(settings.default_timeout_ms)
        try:
            yield page
        finally:
            await context.close()
            await browser.close()


async def open_page(url: str) -> dict:
    console_messages: list[dict] = []
    network_errors: list[dict] = []
    async with browser_page() as page:
        page.on("console", lambda msg: console_messages.append({"type": msg.type, "text": msg.text}))
        page.on("requestfailed", lambda req: network_errors.append({"url": req.url, "failure": req.failure}))
        response = await page.goto(url, wait_until="domcontentloaded", timeout=settings.default_timeout_ms)
        title = await page.title()
        html = await page.content()
        return {
            "url": page.url,
            "title": title,
            "status": response.status if response else None,
            "html": html,
            "console_messages": console_messages,
            "network_errors": network_errors,
        }


async def take_screenshot(url: str, output: str | None = None, full_page: bool = True) -> dict:
    target = Path(output) if output else settings.report_dir / "screenshot.png"
    target.parent.mkdir(parents=True, exist_ok=True)
    async with browser_page() as page:
        await page.goto(url, wait_until="domcontentloaded", timeout=30000)
        await page.screenshot(path=str(target), full_page=full_page)
        return {"url": page.url, "screenshot_path": str(target)}
