from __future__ import annotations

import time
from typing import Any

from fastmcp import FastMCP

from web_qa_mcp_agent.ai.analyzer import LLMConfigurationError, analyze_with_llm
from web_qa_mcp_agent.audit import inspect_page, run_full_audit
from web_qa_mcp_agent.auditors.console import audit_console_errors
from web_qa_mcp_agent.auditors.runtime_accessibility import audit_runtime_accessibility
from web_qa_mcp_agent.auditors.runtime_seo import audit_runtime_seo
from web_qa_mcp_agent.browser.controller import take_screenshot
from web_qa_mcp_agent.browser.journey import run_web_journey
from web_qa_mcp_agent.config import settings
from web_qa_mcp_agent.github.client import (
    GitHubConfigurationError,
    create_issue,
    create_or_get_branch,
    create_pull_request,
    get_repo_info,
    list_open_issues,
    push_file,
)
from web_qa_mcp_agent.models import AuditResult
from web_qa_mcp_agent.reports.ai_markdown import audit_to_github_issue_body, write_ai_audit_report
from web_qa_mcp_agent.reports.html_report import generate_html_report
from web_qa_mcp_agent.reports.markdown import to_markdown, write_reports

mcp = FastMCP("Web QA MCP Agent")

# ──────────────────────────────────────────────
# CORE AUDIT TOOLS
# ──────────────────────────────────────────────

@mcp.tool()
async def browser_snapshot(url: str) -> dict[str, Any]:
    """Open a URL and return title, HTTP status, HTML size, SEO and accessibility quick findings."""
    return await inspect_page(url)


@mcp.tool()
async def screenshot_page(url: str, filename: str = "screenshot.png", full_page: bool = True) -> dict[str, Any]:
    """Take a browser screenshot of any URL and save it to the reports directory."""
    output = settings.report_dir / filename
    return await take_screenshot(url, str(output), full_page)


@mcp.tool()
async def audit_website(url: str, check_links: bool = True) -> dict[str, Any]:
    """Run a full QA audit: security, accessibility, SEO, performance, console, network and links.
    Returns structured JSON with score, findings and metadata."""
    t0 = time.monotonic()
    result = await run_full_audit(url, check_links=check_links)
    result.duration_ms = int((time.monotonic() - t0) * 1000)
    paths = write_reports(result)
    payload = result.model_dump()
    payload["report_paths"] = paths
    return payload


@mcp.tool()
async def audit_markdown_report(url: str, check_links: bool = True) -> str:
    """Run a full QA audit and return the report as formatted Markdown (great for reading in Claude)."""
    t0 = time.monotonic()
    result = await run_full_audit(url, check_links=check_links)
    result.duration_ms = int((time.monotonic() - t0) * 1000)
    write_reports(result)
    return to_markdown(result)


@mcp.tool()
async def compare_two_pages(url_a: str, url_b: str) -> dict[str, Any]:
    """Audit two URLs and compare their score, finding counts and metadata side by side."""
    import asyncio
    a, b = await asyncio.gather(
        run_full_audit(url_a, check_links=False),
        run_full_audit(url_b, check_links=False),
    )
    return {
        "page_a": {
            "url": a.url, "score": a.score, "score_label": a.score_label,
            "findings": len(a.findings), "critical": a.critical_count,
            "high": a.high_count, "metadata": a.metadata,
        },
        "page_b": {
            "url": b.url, "score": b.score, "score_label": b.score_label,
            "findings": len(b.findings), "critical": b.critical_count,
            "high": b.high_count, "metadata": b.metadata,
        },
        "score_delta_b_minus_a": b.score - a.score,
        "finding_delta_b_minus_a": len(b.findings) - len(a.findings),
        "winner": a.url if a.score >= b.score else b.url,
    }


@mcp.tool()
async def export_audit_schema() -> dict[str, Any]:
    """Return the JSON schema of an AuditResult — useful for integrations and documentation."""
    return AuditResult.model_json_schema()


# ──────────────────────────────────────────────
# BROWSER & JOURNEY TOOLS
# ──────────────────────────────────────────────

@mcp.tool()
async def web_journey_tester(steps: list[dict[str, Any]]) -> dict[str, Any]:
    """Run a multi-step browser journey. Actions: goto, click, fill, press, screenshot,
    wait_for_selector, expect_url_contains, expect_text, scroll_to, hover, select_option."""
    return await run_web_journey(steps)


@mcp.tool()
async def accessibility_quick_scan(url: str) -> dict[str, Any]:
    """Run a live browser-based accessibility scan (ARIA, roles, contrast, keyboard nav)."""
    return await audit_runtime_accessibility(url)


@mcp.tool()
async def seo_audit(url: str) -> dict[str, Any]:
    """Run a live browser-based SEO audit (meta tags, structured data, canonical, robots)."""
    return await audit_runtime_seo(url)


@mcp.tool()
async def console_error_audit(url: str) -> dict[str, Any]:
    """Capture JavaScript console errors, page errors and failed network requests."""
    return await audit_console_errors(url)


@mcp.tool()
async def generate_audit_html_report(url: str) -> dict[str, Any]:
    """Generate a beautiful HTML report with SEO, accessibility and console audit data."""
    import asyncio
    seo, accessibility, console = await asyncio.gather(
        audit_runtime_seo(url),
        audit_runtime_accessibility(url),
        audit_console_errors(url),
    )
    t0 = time.monotonic()
    result = await run_full_audit(url, check_links=False)
    result.duration_ms = int((time.monotonic() - t0) * 1000)
    output_path = generate_html_report(url=url, seo=seo, accessibility=accessibility, console=console, audit_result=result)
    return {"url": url, "report_path": output_path, "score": result.score, "findings": len(result.findings)}


# ──────────────────────────────────────────────
# AI ANALYSIS TOOLS
# ──────────────────────────────────────────────

@mcp.tool()
async def ai_web_audit(url: str, check_links: bool = False, write_report: bool = True) -> dict[str, Any]:
    """Run a full QA audit then ask the configured LLM (Anthropic or OpenAI) to explain
    issues, business impact, risk level and recommended next actions."""
    t0 = time.monotonic()
    result = await run_full_audit(url, check_links=check_links)
    result.duration_ms = int((time.monotonic() - t0) * 1000)
    raw_audit = result.model_dump()

    try:
        ai_analysis = await analyze_with_llm(raw_audit)
    except LLMConfigurationError as exc:
        return {
            "url": url,
            "configured": False,
            "error": str(exc),
            "how_to_fix": (
                "Set LLM_PROVIDER=anthropic + ANTHROPIC_API_KEY, "
                "or LLM_PROVIDER=openai + OPENAI_API_KEY in .env and restart."
            ),
            "raw_audit": raw_audit,
        }

    payload: dict[str, Any] = {
        "url": result.url,
        "score": result.score,
        "score_label": result.score_label,
        "findings_count": len(result.findings),
        "critical_count": result.critical_count,
        "raw_audit": raw_audit,
        "ai_analysis": ai_analysis,
    }

    if write_report:
        payload["report_paths"] = write_ai_audit_report(result.url, raw_audit, ai_analysis)

    return payload


@mcp.tool()
async def ai_audit_markdown_report(url: str, check_links: bool = False) -> str:
    """Run the AI-powered QA audit and return a Markdown report ready for GitHub, Notion or docs."""
    payload = await ai_web_audit(url=url, check_links=check_links, write_report=True)
    if not payload.get("ai_analysis"):
        return f"# AI Web QA Audit could not run\n\n{payload.get('error')}\n\n{payload.get('how_to_fix', '')}"
    return payload["ai_analysis"]["analysis_markdown"]


# ──────────────────────────────────────────────
# GITHUB INTEGRATION TOOLS
# ──────────────────────────────────────────────

@mcp.tool()
async def github_repo_info() -> dict[str, Any]:
    """Return basic info about the configured GitHub repository (owner, repo, branch, open issues)."""
    try:
        return await get_repo_info()
    except GitHubConfigurationError as exc:
        return {"configured": False, "error": str(exc),
                "how_to_fix": "Set GITHUB_TOKEN, GITHUB_OWNER and GITHUB_REPO in .env"}


@mcp.tool()
async def github_create_issue(
    title: str,
    body: str,
    labels: list[str] | None = None,
) -> dict[str, Any]:
    """Create a GitHub issue in the configured repository.
    Returns the issue number and URL."""
    try:
        return await create_issue(title=title, body=body, labels=labels or [])
    except GitHubConfigurationError as exc:
        return {"configured": False, "error": str(exc)}
    except Exception as exc:
        return {"error": str(exc)}


@mcp.tool()
async def github_push_report(
    file_path: str,
    content: str,
    commit_message: str,
    branch: str | None = None,
) -> dict[str, Any]:
    """Push any text content (Markdown report, JSON, etc.) to a file in the GitHub repository.
    Creates the file if it doesn't exist, updates it if it does."""
    try:
        return await push_file(
            file_path=file_path,
            content=content,
            commit_message=commit_message,
            branch=branch or settings.github_default_branch,
        )
    except GitHubConfigurationError as exc:
        return {"configured": False, "error": str(exc)}
    except Exception as exc:
        return {"error": str(exc)}


@mcp.tool()
async def github_list_issues(label: str | None = None) -> dict[str, Any]:
    """List open issues in the configured GitHub repository, optionally filtered by label."""
    try:
        issues = await list_open_issues(label=label)
        return {"count": len(issues), "issues": issues}
    except GitHubConfigurationError as exc:
        return {"configured": False, "error": str(exc)}
    except Exception as exc:
        return {"error": str(exc)}


@mcp.tool()
async def github_create_branch(branch_name: str, from_branch: str | None = None) -> dict[str, Any]:
    """Create a new branch in the GitHub repository from the default branch (or a specified one)."""
    try:
        return await create_or_get_branch(branch_name=branch_name, from_branch=from_branch)
    except GitHubConfigurationError as exc:
        return {"configured": False, "error": str(exc)}
    except Exception as exc:
        return {"error": str(exc)}


@mcp.tool()
async def github_create_pull_request(
    title: str,
    body: str,
    head_branch: str,
    base_branch: str | None = None,
    labels: list[str] | None = None,
) -> dict[str, Any]:
    """Open a Pull Request from head_branch into base_branch (defaults to the main branch)."""
    try:
        return await create_pull_request(
            title=title, body=body,
            head_branch=head_branch,
            base_branch=base_branch,
            labels=labels,
        )
    except GitHubConfigurationError as exc:
        return {"configured": False, "error": str(exc)}
    except Exception as exc:
        return {"error": str(exc)}


# ──────────────────────────────────────────────
# COMPOSITE / WORKFLOW TOOLS
# ──────────────────────────────────────────────

@mcp.tool()
async def audit_and_create_github_issue(
    url: str,
    use_ai: bool = True,
    labels: list[str] | None = None,
    only_if_score_below: int = 100,
) -> dict[str, Any]:
    """Run a full QA audit (optionally AI-powered) and automatically create a GitHub issue
    with the findings. Only creates an issue if score is below `only_if_score_below`."""
    t0 = time.monotonic()
    result = await run_full_audit(url, check_links=False)
    result.duration_ms = int((time.monotonic() - t0) * 1000)
    raw_audit = result.model_dump()

    ai_analysis: dict[str, Any] | None = None
    if use_ai:
        try:
            ai_analysis = await analyze_with_llm(raw_audit)
        except LLMConfigurationError:
            ai_analysis = None

    if result.score >= only_if_score_below:
        return {
            "url": url,
            "score": result.score,
            "issue_created": False,
            "reason": f"Score {result.score} >= threshold {only_if_score_below}",
        }

    issue_body = audit_to_github_issue_body(url, result, ai_analysis)
    issue_labels = labels or ["qa-audit", "automated"]
    score_label = "critical" if result.score < 50 else "needs-work" if result.score < 75 else "review"
    if score_label not in issue_labels:
        issue_labels.append(score_label)

    try:
        issue = await create_issue(
            title=f"🔍 QA Audit: {url} — Score {result.score}/100",
            body=issue_body,
            labels=issue_labels,
        )
        return {
            "url": url,
            "score": result.score,
            "findings": len(result.findings),
            "issue_created": True,
            "issue": issue,
        }
    except GitHubConfigurationError as exc:
        return {"url": url, "score": result.score, "issue_created": False, "error": str(exc)}


@mcp.tool()
async def audit_and_push_report_to_github(
    url: str,
    file_path: str = "reports/latest-audit.md",
    branch: str | None = None,
    use_ai: bool = False,
) -> dict[str, Any]:
    """Run a full QA audit, generate a Markdown report and push it directly to GitHub.
    Optionally enriches the report with AI analysis."""
    t0 = time.monotonic()
    result = await run_full_audit(url, check_links=False)
    result.duration_ms = int((time.monotonic() - t0) * 1000)
    raw_audit = result.model_dump()

    ai_analysis: dict[str, Any] | None = None
    if use_ai:
        try:
            ai_analysis = await analyze_with_llm(raw_audit)
        except LLMConfigurationError:
            pass

    if ai_analysis:
        from web_qa_mcp_agent.reports.ai_markdown import write_ai_audit_report
        write_ai_audit_report(result.url, raw_audit, ai_analysis)
        md_content = f"# 🤖 AI QA Audit — {url}\n\n{ai_analysis['analysis_markdown']}"
    else:
        md_content = to_markdown(result)

    try:
        push_result = await push_file(
            file_path=file_path,
            content=md_content,
            commit_message=f"chore: QA audit report for {url} — score {result.score}/100",
            branch=branch or settings.github_default_branch,
        )
        return {
            "url": url,
            "score": result.score,
            "findings": len(result.findings),
            "github_push": push_result,
            "ai_used": ai_analysis is not None,
        }
    except GitHubConfigurationError as exc:
        return {"url": url, "score": result.score, "pushed": False, "error": str(exc)}


@mcp.tool()
async def full_qa_workflow(
    url: str,
    github_push: bool = True,
    github_issue: bool = True,
    use_ai: bool = True,
    issue_threshold: int = 85,
    report_path: str = "reports/latest-audit.md",
) -> dict[str, Any]:
    """🚀 All-in-one QA workflow: audit → AI analysis → push report to GitHub → create issue if needed.
    The most powerful tool in the suite. Configurable at every step."""
    t0 = time.monotonic()
    result = await run_full_audit(url, check_links=False)
    result.duration_ms = int((time.monotonic() - t0) * 1000)
    raw_audit = result.model_dump()

    ai_analysis: dict[str, Any] | None = None
    if use_ai:
        try:
            ai_analysis = await analyze_with_llm(raw_audit)
        except LLMConfigurationError as exc:
            ai_analysis = None

    # Write local reports
    local_paths = write_reports(result)
    if ai_analysis:
        local_paths.update(write_ai_audit_report(result.url, raw_audit, ai_analysis))

    output: dict[str, Any] = {
        "url": url,
        "score": result.score,
        "score_label": result.score_label,
        "findings": len(result.findings),
        "critical": result.critical_count,
        "high": result.high_count,
        "duration_ms": result.duration_ms,
        "ai_provider": ai_analysis.get("provider") if ai_analysis else None,
        "local_reports": local_paths,
        "github_push_result": None,
        "github_issue_result": None,
    }

    if ai_analysis:
        output["ai_analysis_preview"] = ai_analysis["analysis_markdown"][:500] + "..."

    if github_push:
        md = (
            f"# 🤖 AI QA Audit — {url}\n\n{ai_analysis['analysis_markdown']}"
            if ai_analysis
            else to_markdown(result)
        )
        try:
            output["github_push_result"] = await push_file(
                file_path=report_path,
                content=md,
                commit_message=f"chore: QA audit {url} — score {result.score}/100",
                branch=settings.github_default_branch,
            )
        except (GitHubConfigurationError, Exception) as exc:
            output["github_push_result"] = {"error": str(exc)}

    if github_issue and result.score < issue_threshold:
        issue_body = audit_to_github_issue_body(url, result, ai_analysis)
        try:
            output["github_issue_result"] = await create_issue(
                title=f"🔍 QA Audit: {url} — Score {result.score}/100",
                body=issue_body,
                labels=["qa-audit", "automated", "critical" if result.score < 50 else "needs-work"],
            )
        except (GitHubConfigurationError, Exception) as exc:
            output["github_issue_result"] = {"error": str(exc)}
    elif github_issue:
        output["github_issue_result"] = {
            "skipped": True,
            "reason": f"Score {result.score} >= threshold {issue_threshold}",
        }

    return output


def main() -> None:
    mcp.run(transport="streamable-http", host=settings.host, port=settings.port, path="/mcp")


if __name__ == "__main__":
    main()
