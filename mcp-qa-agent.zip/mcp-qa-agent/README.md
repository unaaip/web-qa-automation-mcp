# 🔍 Web QA MCP Agent

A powerful **Model Context Protocol (MCP) server** for automated web quality assurance. Integrates with **Claude**, **GPT**, and **GitHub** to audit websites, generate AI-powered reports, and automate QA workflows — all from natural language via any MCP-compatible AI client.

---

## ✨ Features

| Category | Capabilities |
|----------|-------------|
| 🧪 **Core Auditing** | Security, SEO, accessibility, performance, links, console errors, network failures |
| 🤖 **AI Analysis** | Multi-LLM support (Anthropic Claude + OpenAI GPT) for business-impact reports |
| 🐙 **GitHub Integration** | Create issues, push reports, create branches and PRs automatically |
| 🌐 **Browser Journeys** | Multi-step flows: click, fill, assert, screenshot, hover, scroll |
| 📊 **Reports** | Markdown, JSON, HTML — local and pushed to GitHub |
| 🔄 **Workflows** | All-in-one pipeline: audit → AI → push report → create issue |

---

## 🛠️ MCP Tools Reference

### Core Audit Tools

| Tool | Description |
|------|-------------|
| `browser_snapshot` | Quick title, status, SEO & a11y snapshot |
| `audit_website` | Full QA audit (JSON) — security, SEO, a11y, performance, links |
| `audit_markdown_report` | Full audit → human-readable Markdown |
| `compare_two_pages` | Side-by-side comparison of two URLs |
| `export_audit_schema` | JSON schema of the audit result model |

### Browser & Journey Tools

| Tool | Description |
|------|-------------|
| `screenshot_page` | Full-page or viewport screenshot |
| `web_journey_tester` | Multi-step browser journey (goto, click, fill, expect, scroll…) |
| `accessibility_quick_scan` | Live ARIA/contrast/keyboard accessibility scan |
| `seo_audit` | Live meta, canonical, structured data SEO audit |
| `console_error_audit` | JS errors, page errors, failed requests |
| `generate_audit_html_report` | Beautiful HTML report saved locally |

### AI Analysis Tools

| Tool | Description |
|------|-------------|
| `ai_web_audit` | Audit + LLM analysis → score, risk level, recommended actions |
| `ai_audit_markdown_report` | AI audit → Markdown ready for GitHub/Notion |

### GitHub Integration Tools

| Tool | Description |
|------|-------------|
| `github_repo_info` | Repository info (branch, open issues, topics) |
| `github_create_issue` | Create a GitHub issue with title, body, labels |
| `github_push_report` | Push any text/Markdown to a file in the repo |
| `github_list_issues` | List open issues (filterable by label) |
| `github_create_branch` | Create a branch from default or specified base |
| `github_create_pull_request` | Open a PR from head → base branch |

### Composite Workflow Tools

| Tool | Description |
|------|-------------|
| `audit_and_create_github_issue` | Audit → create GitHub issue if score below threshold |
| `audit_and_push_report_to_github` | Audit → push Markdown report to GitHub |
| `full_qa_workflow` | 🚀 Audit → AI → push report → create issue (all-in-one) |

---

## 🚀 Quick Start

### Docker (recommended)

```bash
cp .env.example .env
# Fill in your keys in .env
docker compose up --build
```

### Local Development

```bash
pip install -e ".[dev]"
playwright install chromium --with-deps
cp .env.example .env
python -m web_qa_mcp_agent.server
```

---

## ⚙️ Configuration

All configuration is via `.env`. Copy `.env.example` to get started.

```env
# LLM Provider: anthropic | openai
LLM_PROVIDER=anthropic
ANTHROPIC_API_KEY=sk-ant-...
ANTHROPIC_MODEL=claude-3-5-haiku-20241022

# GitHub
GITHUB_TOKEN=ghp_...
GITHUB_OWNER=your-org
GITHUB_REPO=your-repo
GITHUB_DEFAULT_BRANCH=main
```

---

## 🔌 Claude Desktop Integration

Add to `~/.config/claude/claude_desktop_config.json`:

```json
{
  "mcpServers": {
    "web-qa": {
      "url": "http://localhost:8000/mcp"
    }
  }
}
```

---

## 💡 Usage Examples

### Simple audit
> "Audit https://example.com and give me a Markdown report"
→ Claude calls `audit_markdown_report`

### AI-powered analysis
> "Run an AI audit of my homepage and create a GitHub issue if anything critical is found"
→ Claude calls `full_qa_workflow` with `github_issue=true`

### Journey testing
> "Test the login flow on my site: go to /login, fill email and password, click submit, expect /dashboard"
→ Claude calls `web_journey_tester` with steps

### Push report to GitHub
> "Audit my landing page and push the report to the docs/qa folder"
→ Claude calls `audit_and_push_report_to_github`

---

## 🧩 Architecture

```
src/web_qa_mcp_agent/
├── server.py              # FastMCP server — all tool definitions
├── audit.py               # Core audit orchestrator
├── config.py              # Settings (env-driven)
├── models.py              # Pydantic models (Finding, AuditResult…)
├── ai/
│   └── analyzer.py        # Multi-LLM: Anthropic + OpenAI
├── auditors/
│   ├── accessibility.py   # Static HTML a11y checks
│   ├── runtime_accessibility.py  # Live browser a11y
│   ├── console.py         # JS console capture
│   ├── links.py           # Link health checker
│   ├── performance.py     # Core Web Vitals
│   ├── runtime_seo.py     # Live browser SEO
│   ├── security.py        # HTTPS, mixed content, password fields
│   └── seo.py             # Static HTML SEO checks
├── browser/
│   ├── controller.py      # Playwright browser context
│   ├── journey.py         # Multi-step journey runner
│   └── runtime.py         # Runtime helpers
├── github/
│   └── client.py          # GitHub REST API client
└── reports/
    ├── markdown.py        # Markdown report generator
    ├── html_report.py     # HTML report generator
    └── ai_markdown.py     # AI report + GitHub issue formatter
```

---

## 🧪 Running Tests

```bash
pytest -v
```

---

## 📄 License

MIT
