from __future__ import annotations

import pytest
from web_qa_mcp_agent.auditors.security import audit_security
from web_qa_mcp_agent.auditors.seo import audit_seo
from web_qa_mcp_agent.auditors.accessibility import audit_accessibility
from web_qa_mcp_agent.models import AuditResult, Finding


def test_security_flags_http():
    findings = audit_security("http://example.com", "<html></html>")
    assert any(f.category == "security" and "HTTPS" in f.title for f in findings)


def test_security_ok_https():
    findings = audit_security("https://example.com", "<html></html>")
    assert not any(f.title == "Page is not served over HTTPS" for f in findings)


def test_seo_missing_title():
    findings = audit_seo("<html><body></body></html>")
    assert any("title" in f.title.lower() for f in findings)


def test_seo_long_title():
    long_title = "A" * 70
    findings = audit_seo(f"<html><head><title>{long_title}</title></head></html>")
    assert any("Long" in f.title for f in findings)


def test_seo_missing_description():
    findings = audit_seo("<html><head><title>OK</title></head></html>")
    assert any("description" in f.title.lower() for f in findings)


def test_seo_clean_page():
    html = """<html><head>
      <title>Good title</title>
      <meta name="description" content="A good description">
      </head><body><h1>Hello</h1></body></html>"""
    findings = audit_seo(html)
    assert all(f.category != "seo" or f.severity == "low" for f in findings)


def test_audit_result_score():
    result = AuditResult(url="https://example.com")
    result.findings = [
        Finding(severity="high", category="security", title="X", description="X", recommendation="X"),
        Finding(severity="medium", category="seo", title="X", description="X", recommendation="X"),
    ]
    score = result.recalculate_score()
    assert score == 100 - 15 - 8


def test_audit_result_score_label():
    result = AuditResult(url="https://example.com", score=95)
    assert result.score_label == "Excellent"
    result.score = 80
    assert result.score_label == "Good"
    result.score = 60
    assert result.score_label == "Needs Attention"
    result.score = 30
    assert result.score_label == "Critical"


def test_findings_by_severity():
    result = AuditResult(url="https://example.com")
    result.findings = [
        Finding(severity="high", category="security", title="X", description="X", recommendation="X"),
        Finding(severity="high", category="seo", title="Y", description="Y", recommendation="Y"),
        Finding(severity="low", category="a11y", title="Z", description="Z", recommendation="Z"),
    ]
    by_sev = result.findings_by_severity
    assert len(by_sev["high"]) == 2
    assert len(by_sev["low"]) == 1
    assert len(by_sev["critical"]) == 0
