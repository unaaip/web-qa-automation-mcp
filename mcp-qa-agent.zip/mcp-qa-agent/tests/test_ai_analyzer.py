from __future__ import annotations

import pytest
from web_qa_mcp_agent.ai.analyzer import build_qa_prompt, _compact_payload, LLMConfigurationError


def test_prompt_contains_json():
    data = {"url": "https://example.com", "score": 75, "findings": []}
    prompt = build_qa_prompt(data)
    assert "```json" in prompt
    assert "Executive Summary" in prompt
    assert "Risk Level" in prompt


def test_compact_payload_truncates():
    big_data = {"data": "x" * 20000}
    result = _compact_payload(big_data, max_chars=5000)
    assert len(result) <= 5050  # some tolerance
    assert "truncated" in result


def test_compact_payload_short():
    small = {"url": "https://example.com"}
    result = _compact_payload(small, max_chars=5000)
    assert "truncated" not in result


def test_llm_config_error_is_runtime():
    exc = LLMConfigurationError("test")
    assert isinstance(exc, RuntimeError)
