from __future__ import annotations

import pytest
from web_qa_mcp_agent.github.client import GitHubConfigurationError


def test_github_config_error_is_runtime():
    exc = GitHubConfigurationError("missing token")
    assert isinstance(exc, RuntimeError)
    assert "missing token" in str(exc)
